/**
 * The abstracted mljsserve web server library
 */
var server = {

};

module.exports = server;
